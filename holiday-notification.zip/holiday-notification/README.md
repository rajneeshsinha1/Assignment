# holiday-notification
**Requirements**

For building and running the application we need:

- JDK 1.8
- Maven 3

**To run the application**

Download and import the project in Spring Tool Suite.
Enter the Source mail username and paasword in application.properties file.
Add the Destination mail username in email-input.csv file present in resources folder.
Create a database in MySQL server and configure it in application.properties file.
Start the application.
Add the holiday list input json data one-by-one present in holiday_list-json-input.txt under resources folder using POSTMAN.
Use the below URL to add the json input data.
URL: http://localhost:8081/holiday/add

For Slack:
Scheduler will run everyday and it hits the database if its found next day is holiday then it will call the method to send the message in slack.

For email:
It will fetch the holiday list from database and send to all the email present in email-input.csv file.
Scheduler will schedule the next email send event based on configured time.
