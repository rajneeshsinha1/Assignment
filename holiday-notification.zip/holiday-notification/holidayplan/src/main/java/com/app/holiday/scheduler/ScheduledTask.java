package com.app.holiday.scheduler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.app.holiday.service.HolidayService;

@Component
public class ScheduledTask {
	
	@Autowired
	HolidayService holidayService;
	
	@Scheduled(cron = "0 0 14 * * ?", zone = "Asia/Kolkata")
	public void callSendMail() {
		
		//for sendingg email notification uncomment the below code
		//holidayService.sendTextEmail();
		boolean holiday = holidayService.getHoliday();
		if (holiday) {
			holidayService.sendMessageToSlack();
		}
	}
}
