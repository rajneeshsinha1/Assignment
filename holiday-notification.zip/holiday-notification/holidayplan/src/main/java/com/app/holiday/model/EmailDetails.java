package com.app.holiday.model;

import java.io.Serializable;

import javax.validation.constraints.Email;

import org.springframework.stereotype.Component;

@Component
public class EmailDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Email
	private String sendTo;
	private String userName;

	public String getSendTo() {
		return sendTo;
	}

	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String toString() {
		return "EmailDetails [sendTo=" + sendTo + ", userName=" + userName + "]";
	}
	
	

}
