package com.app.holiday.service;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.app.holiday.dto.HolidayDTO;
import com.app.holiday.model.EmailDetails;
import com.app.holiday.model.Holiday;
import com.app.holiday.repository.HolidayRepository;
import com.github.seratch.jslack.Slack;
import com.github.seratch.jslack.api.webhook.Payload;
import com.github.seratch.jslack.api.webhook.WebhookResponse;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

@Service
public class HolidayService {

	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private HolidayRepository holidayRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Configuration config;

	@Value("${email.subject}")
	private String subject;

	@Value("${email.senderName}")
	private String senderName;

	@Value("${slack.webhook}")
	private String slackWebhook;

	HolidayDTO holidayDTO = null;

	private final String path = "src/main/resources/email-input.csv";

	// This method is used to get the email ids with help of getEmailDetails and
	// send notification to all the email ids
	@Async
	public String sendTextEmail() {
		MimeMessage message = javaMailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			List<Holiday> holidays = holidayRepository.findAll();
			List<HolidayDTO> holidayDTOs = Arrays.asList(modelMapper.map(holidays, HolidayDTO[].class));
			Template template = config.getTemplate("email-template.ftl");
			List<EmailDetails> emailDetailsList = getEmailDetails();
			Map<String, Object> params = new HashMap<>();
			params.put("holidayDTOs", holidayDTOs);
			params.put("senderName", senderName);
			for (int i = 0; i < emailDetailsList.size(); i++) {
				params.put("userName", emailDetailsList.get(i).getUserName());
				String holidayStr = FreeMarkerTemplateUtils.processTemplateIntoString(template, params);
				helper.setTo(emailDetailsList.get(i).getSendTo());
				helper.setSubject(subject);
				helper.setText(holidayStr, true);
				javaMailSender.send(message);
			}

		} catch (MailException | IOException | TemplateException | MessagingException e) {
			System.out.println(e.getMessage());
			return "Exception Occured" + e.getMessage();
		}
		return "Email sent";
	}

	// This method is used to get the holiday record from HolidayDTO with the help
	// of getHoliday method and send the
	// notification to slack by calling process method.
	public void sendMessageToSlack() {
		StringBuilder msgBuilder = new StringBuilder();
		msgBuilder.append("*Holiday Notification:* " + "Tomorrow will be holiday on occasion of "
				+ holidayDTO.getOccasion() + "\n");
		msgBuilder.append("Stay Safe Stay Healthy");
		process(msgBuilder.toString());
	}

	private void process(String msg) {
		Payload payload = Payload.builder().channel("#alert").username("Notification").text(msg).build();
		try {
			WebhookResponse wResponse = Slack.getInstance().send(slackWebhook, payload);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// This method will fetch the holiday record from holiday table(if record
	// present) and stored in HolidayDTO
	public boolean getHoliday() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		Date tomorrow = calendar.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String format = sdf.format(tomorrow);
		Holiday holiday = holidayRepository.findByDate(format);
		if (holiday == null) {
			System.out.println("There is no holiday for entered date");
			return false;
		}
		holidayDTO = modelMapper.map(holiday, HolidayDTO.class);
		return true;
	}

	// This method will read the list of email present in the file
	public List<EmailDetails> getEmailDetails() {
		List<EmailDetails> emailDetailsList = new ArrayList<EmailDetails>();
		String line = "";
		try {
			BufferedReader br = new BufferedReader(new FileReader(path));
			while ((line = br.readLine()) != null) {
				String[] split = line.split(",");
				EmailDetails emailDetails = new EmailDetails();
				emailDetails.setSendTo(split[0]);
				emailDetails.setUserName(split[1]);
				emailDetailsList.add(emailDetails);
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return emailDetailsList;
	}
}
