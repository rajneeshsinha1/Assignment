package com.app.holiday.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.holiday.model.Holiday;
import com.app.holiday.repository.HolidayRepository;
import com.app.holiday.service.HolidayService;

@RestController
@RequestMapping("/holiday")
public class HolidayController {

	@Autowired
	HolidayRepository holidayRepository;

	@Autowired
	HolidayService holidayService;

	@PostMapping(value = "/add", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Holiday> addHoliday(@RequestBody Holiday holiday) {
		long count = holidayRepository.count();
		holiday.setId(count + 1);
		holidayRepository.save(holiday);
		return new ResponseEntity<Holiday>(holiday, HttpStatus.OK);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Long> deleteHoliday(@PathVariable(value = "id") Long id) {
		Optional<Holiday> holiday = holidayRepository.findById(id);
		if (holiday == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		holidayRepository.deleteById(id);
		return new ResponseEntity<Long>(HttpStatus.OK);
	}

}
